# P5 消融、鲁棒性与升级实验阶段报告

本次仅执行用户指定的第六阶段 **P5**。P0–P4 原始证据保留；P6 未启动。实验完成与算法优越性、工程实时目标达成分别判断。

正式调用共 **381,200** 次（含验证子集阈值校准720次，训练预热/训练预检另存，不计测试样本）。300基实例消融、100基实例专项、50冻结异常和50配对正常对照均使用事前固定列表；同一基实例的变体、事件、种子不作为新增独立样本。

## 1. 已确认范围与方法契约

- 规则主线：固定w5/B2、只调B、只调w、联合规则；默认参数沿用P3冻结版本，验证择优固定w5/B1，不用P5结果重新选参。ET未运行，A6不适用；这不支持学习控制贡献。
- 共享升级：合作式PALR子预算10ms，完整实际开销计入共享50ms，已验证incumbent和累计接纳轨迹传给剩余时间搜索。触发只看紧急是否服务或效用恢复比；阈值仅在预定验证60基实例上从{0.95,1.0}选择。
- IPC：按用户确认完成固定来源、结构解析、去重/同源与适用性审计；缺少完整时序规划及验证适配器，因此没有IPC性能实验。未扁平化替代PDDL，未把未执行写成0可解。
- 同邻域机制固定w5/B2、同E外承诺及候选资格；全后缀操作比较另表，不能将邻域差异归因为搜索策略。

完整执行协议见 [P5_EXECUTION_V1.md](https://github.com/Liu-Jiye/Online-Resilience-Reconstruction-of-Satellite-Information-Distribution-Task-Schemes/blob/27fa69fa54fff94d31ec8b946fac8a41797f59d0/experiment_runs/protocol/P5_EXECUTION_V1.md)，实际来源与代码版本见每批source_freeze.json、environment.json。P5前的五阶段评估及复算证据一并交付于[prior_stage_review](https://github.com/Liu-Jiye/Online-Resilience-Reconstruction-of-Satellite-Information-Distribution-Task-Schemes/blob/27fa69fa54fff94d31ec8b946fac8a41797f59d0/experiment_runs/reports/p5/P5-20261118/prior_stage_review/P0_P4_REVIEW.md)，保留原评估结论，不改写旧阶段报告。

## 2. 实际规模与适用状态

| phase | calls | event_conditions | base_clusters |
|---|---|---|---|
| ablations | 169200 | 154800 | 300 |
| anomalies | 400 | 400 | 50 |
| calibration | 720 | 720 | 60 |
| continuous | 4000 | 4000 | 100 |
| mechanisms | 14400 | 4800 | 100 |
| references | 4800 | 4800 | 100 |
| simulations | 18000 | 3600 | 100 |
| single_factor | 99840 | 99840 | 100 |
| transfer | 1440 | 1440 | 30 |
| upgrades | 25200 | 6000 | 100 |
| windows | 43200 | 43200 | 100 |

消融三层各100基实例，汇总权重各1/3；专项100为D1/D2-S/D2-O=40/30/30。跨星座迁移为30个OneWeb测试基实例。各表只在各自固定子集内比较，不将重叠阶段累加为独立总体。

| 项目 | 实际处理 | 验收含义 |
|---|---|---|
| A1/A2 | 搜索中分别忽略窗口/接收资源，末端完整校验；300自然基实例与100窗口配对压力 | 错误模型诊断，非法输出计失败 |
| A3 | w5，B=0/1/2/3/5 | 三扰动均保留，B0紧急限制另解释 |
| A4 | B2，w=1/3/5/10/20 | 原参考索引邻域，E外承诺不变 |
| A5 | 固定/仅B/仅w/联合规则 | 完成最低消融要求，ET行N/A |
| A6 | 不适用 | 用户批准规则主线，未进行ET重训 |
| A7 | 禁替换仅插入 vs 完整算子 | 与固定w5/B2配对 |
| A8 | 5固定种子随机并列裁决 vs 完整干扰词典序 | 种子在事件内平均，不取最好种子 |
| A9 | 默认、验证最佳、25动作逐基实例离线选择；另列逐事件包络 | 每基实例选一个动作并保留其12事件；两种离线结果均非在线方法或精确最优 |
| A10 | 5/10/20/50/100ms，有/无剩余时间特征 | 固定其余规则，50ms单独成对调用不与A5重复合并 |

## 3. 消融主结果与结论边界

| label | applicable | success_equivalent | online_success | U_exec_mean | conditional_N_drop | conditional_N_add | conditional_M_all | p95_ms | timeout_rate |
|---|---|---|---|---|---|---|---|---|---|
| B-only | 3600 | 2638.000 | 73.28% | 2470.406 | 0.003 | 0.157 | 0.000 | 17.235 | 0.00% |
| Grid-w5-B1 | 3600 | 2637.000 | 73.25% | 2470.034 | 0.038 | 0.177 | 0.000 | 15.983 | 0.03% |
| Grid-w5-B2 | 3600 | 2636.000 | 73.22% | 2472.207 | 0.023 | 0.199 | 1.802 | 17.268 | 0.00% |
| Insert-only | 3600 | 2632.000 | 73.11% | 2470.105 | 0.000 | 0.157 | 0.000 | 14.936 | 0.00% |
| Minimal-Repair | 3600 | 2632.000 | 73.11% | 2464.747 | 0.000 | 0.064 | 0.000 | 13.658 | 0.03% |
| No-receiver | 3600 | 35.000 | 0.97% | 98.286 | 0.024 | 0.106 | 0.976 | 26.795 | 0.03% |
| No-window | 3600 | 30.000 | 0.83% | 44.846 | 0.000 | 0.264 | 0.000 | 30.891 | 0.03% |
| Random-ties | 3600 | 2638.800 | 73.30% | 2472.432 | 0.022 | 0.199 | 1.826 | 17.274 | 0.00% |
| Rule-PALR | 3600 | 2638.000 | 73.28% | 2470.399 | 0.003 | 0.157 | 0.000 | 17.332 | 0.00% |
| w-only | 3600 | 2638.000 | 73.28% | 2471.366 | 0.019 | 0.193 | 1.391 | 18.559 | 0.03% |

联合规则对固定w5/B2的成功率差为 **+0.056个百分点**，P5探索性95%区间[-0.056, +0.167]个百分点；对验证最佳w5/B1为 **+0.028个百分点**，区间[-0.056, +0.111]个百分点。下文配对差值表中以百分号显示的差值均表示成功率的绝对差，例如1%表示1个百分点，不是相对增长率。是否支持优势须依据差值和区间，不能把阶段完成写成联合规则有效提升。

在该固定三扰动混合下，联合规则相对固定w5/B2的平均执行效用差为-1.808，探索性95%区间[-2.516, -1.131]；双方均有效事件中的平均移动差为-1.802，删除差为-0.020。应同时解释效用、干扰和成功率，不以单项很小的成功数增加宣布整体优势；各扰动的效用尺度分面单列。

区间是固定轨道组条件下的分层配对基实例簇bootstrap（2000次、固定种子20261118），用于P5内部诊断；不代表跨卫星组总体泛化推断，也不代替P6。主成功率及U_exec保留失败和超时。条件效用/干扰仅对预算内有效输出，分母在表中；双方均有效的配对质量另见paired_exploratory_intervals.csv，不把不同有效子集均值当因果改善。

A3/A4完整网格、分层和分扰动结果均已导出。B增加允许更多累计新接纳，但可能增加开销；w增加扩展原索引邻域，同样不保证有限时限内成功率单调。B0紧急不能被新接纳的限制属于结构性质，不据此证明更大预算在其他扰动上必然更优。

A8随机版本保持服务/效用优先，只接受主目标严格改善并随机裁决主目标相同的候选。它检验此实现的裁决规则，不等于任意无干扰目标算法。A9按原方案逐基实例从25动作中选择一个动作：先比较该基实例全部12事件的成功总数、执行效用总和，再按删除/增加/移动/总时间/动作序号裁决；完整保留所选动作全部12事件。选择读取测试结果，因此仅为事后诊断，不能部署。

| label | applicable | online_success | U_exec_mean | p95_ms | timeout_rate |
|---|---|---|---|---|---|
| Grid-w5-B2 | 3600 | 73.22% | 2472.207 | 17.268 | 0.00% |
| Grid-w5-B1 | 3600 | 73.25% | 2470.034 | 15.983 | 0.03% |
| Offline-per-base-grid | 3600 | 73.31% | 2476.511 | 26.253 | 0.00% |

A9_per_base_selected_actions.csv保存每基实例所选动作和选择分数。额外逐事件包络从25个独立50ms调用中选择，见A9_oracle_summary.csv；它比每基实例固定一个动作更乐观，单独报告。两者累计离线开销均不属于在线50ms，不构成精确最优证明。

图：[B/w前沿](https://github.com/Liu-Jiye/Online-Resilience-Reconstruction-of-Satellite-Information-Distribution-Task-Schemes/blob/27fa69fa54fff94d31ec8b946fac8a41797f59d0/experiment_runs/reports/p5/P5-20261118/figures/ablation_B_w.png)、[A5控制消融](https://github.com/Liu-Jiye/Online-Resilience-Reconstruction-of-Satellite-Information-Distribution-Task-Schemes/blob/27fa69fa54fff94d31ec8b946fac8a41797f59d0/experiment_runs/reports/p5/P5-20261118/figures/A5_rule_control.png)、[A10响应预算](https://github.com/Liu-Jiye/Online-Resilience-Reconstruction-of-Satellite-Information-Distribution-Task-Schemes/blob/27fa69fa54fff94d31ec8b946fac8a41797f59d0/experiment_runs/reports/p5/P5-20261118/figures/A10_response_budget.png)、[分扰动效用—干扰](https://github.com/Liu-Jiye/Online-Resilience-Reconstruction-of-Satellite-Information-Distribution-Task-Schemes/blob/27fa69fa54fff94d31ec8b946fac8a41797f59d0/experiment_runs/reports/p5/P5-20261118/figures/utility_disturbance.png)、[完整调用时延分解](https://github.com/Liu-Jiye/Online-Resilience-Reconstruction-of-Satellite-Information-Distribution-Task-Schemes/blob/27fa69fa54fff94d31ec8b946fac8a41797f59d0/experiment_runs/reports/p5/P5-20261118/figures/A5_timing_decomposition.png)。A5时延分解逐调用核对各独占分项之和等于完整外层时延，返回/指标/分派成本另列，不能拿内核时延代替总响应。

A10完整配对结果如下；比较的是冻结规则控制器的单特征屏蔽，所有提取与控制成本均计时。成功率差值及区间不支持稳定增益时，不能声称剩余时间特征贡献已成立。

| left | paired_events | online_success_difference | online_success_ci95_low | online_success_ci95_high | U_exec_difference |
|---|---|---|---|---|---|
| Rule-PALR@5ms | 3600 | 0.11% | -0.47% | 0.72% | 0.806 |
| Rule-PALR@10ms | 3600 | 1.03% | -0.69% | 2.86% | 21.323 |
| Rule-PALR@20ms | 3600 | 0.31% | -0.28% | 0.89% | -1.599 |
| Rule-PALR@50ms | 3600 | 0.00% | 0.00% | 0.00% | -0.026 |
| Rule-PALR@100ms | 3600 | 0.00% | 0.00% | 0.00% | 0.000 |

## 4. 窗口与双端资源诊断

| label | calls | final_rejected | physical_illegal_plans | plans_with_window_violation | plans_with_resource_violation | online_success |
|---|---|---|---|---|---|---|
| No-receiver | 3600 | 3477 | 3477 | 0 | 396 | 35 |
| No-window | 3600 | 3547 | 3547 | 3547 | 0 | 30 |

最终严格检查拒绝的输出始终计失败。物理计划非法数与最终拒绝数可以不同：最终拒绝还包括轨迹/累计接纳等契约；不能用非法计划的原始效用展示质量优势。自然输入中某约束反例少，表示该分布证据弱，不能得出约束可删除。

| label | variant | calls | final_rejected | plans_with_window_violation | plans_with_resource_violation | online_success |
|---|---|---|---|---|---|---|
| No-receiver | delete_one | 1200 | 1041 | 0 | 83 | 42 |
| No-receiver | p0.1_shrink0.1 | 1200 | 1042 | 0 | 81 | 50 |
| No-receiver | p0.1_shrink0.3 | 1200 | 1040 | 0 | 85 | 46 |
| No-receiver | p0.3_shrink0.1 | 1200 | 1042 | 0 | 83 | 43 |
| No-receiver | p0.3_shrink0.3 | 1200 | 1050 | 0 | 76 | 39 |
| No-receiver | targeted_pressure | 1200 | 1034 | 0 | 76 | 43 |
| No-window | delete_one | 1200 | 1199 | 1172 | 0 | 0 |
| No-window | p0.1_shrink0.1 | 1200 | 1093 | 1063 | 0 | 30 |
| No-window | p0.1_shrink0.3 | 1200 | 1124 | 1105 | 0 | 28 |
| No-window | p0.3_shrink0.1 | 1200 | 1126 | 1096 | 0 | 20 |
| No-window | p0.3_shrink0.3 | 1200 | 1170 | 1147 | 0 | 10 |
| No-window | targeted_pressure | 1200 | 1200 | 1173 | 0 | 0 |

配对压力由输入ID确定可编辑任务，并缩短其支持接触到不足任务时长；它证明原位置失效，不是全局不可行证书。常规压力保护冻结支持窗口，冻结异常另组。窗口确实改变和未改变的条件均保留，不重抽。实际变动及原位置失效证书计数见input_independent_audit.json；外生强制移除N_forced单列，不计主动删除。

## 5. 单因素鲁棒性

N50/100/200/500/1000严格使用同一随机序列任务前缀；N100与原输入逐字段一致。热点0/.5/.8、跨度120/300/600、速率50/100/200、背景日历0/.5/.8、FR0/.3/.6/.8均逐因素改变；距离2000/3500/5000只在60个D2实例上重算同轨道对象接触，D1标N/A。独立审计验证因子隔离、任务前缀、距离窗口包含关系及参考可行性。

这些输入会重建共享参考计划，变化同时影响初始接纳和随后事件/冻结成员，不能把结果完全归因为修复器规模复杂度。固定需求指基实例任务；紧急请求按原事件生成协议和固定随机种子重新生成，其独立速率仍从50/100/200 Mbps抽样，距离改变也可能经候选接触对集合改变紧急请求端点。因此速率曲线是基任务速率敏感性，距离曲线是重新生成事件后的整体场景敏感性，不应称为所有请求共同固定速率或完全相同紧急请求的物理链路因果实验。空参考/自然不可行与N/A均保留；输入参考变化、空参考数及原始指标见tables/input_reference_changes.csv。高负载若增加超时，应按完整调用结果解释，不以离线校验挽救。

完整曲线见[single_factor_success.png](https://github.com/Liu-Jiye/Online-Resilience-Reconstruction-of-Satellite-Information-Distribution-Task-Schemes/blob/27fa69fa54fff94d31ec8b946fac8a41797f59d0/experiment_runs/reports/p5/P5-20261118/figures/single_factor_success.png)，FR×窗口压力见[FR_window_stress.png](https://github.com/Liu-Jiye/Online-Resilience-Reconstruction-of-Satellite-Information-Distribution-Task-Schemes/blob/27fa69fa54fff94d31ec8b946fac8a41797f59d0/experiment_runs/reports/p5/P5-20261118/figures/FR_window_stress.png)。逐条件、分FR/q表与种子原始行均保留。

联合规则的逐因素完整截止结果如下。每行属于对应固定子集，因子间不可相加成独立样本；所有四方法对照见single_factor_summary.csv。

| factor | value | applicable | online_success | U_exec_mean | p95_ms | timeout_rate |
|---|---|---|---|---|---|---|
| FR | 0.000 | 600 | 74.50% | 2312.665 | 28.794 | 0.33% |
| FR | 0.300 | 600 | 73.33% | 2447.807 | 27.842 | 0.33% |
| FR | 0.600 | 600 | 73.17% | 2584.492 | 31.068 | 0.17% |
| FR | 0.800 | 600 | 72.83% | 2663.602 | 28.210 | 0.67% |
| N | 50.000 | 1200 | 74.08% | 1273.408 | 19.731 | 0.17% |
| N | 100.000 | 1200 | 73.58% | 2445.818 | 29.278 | 0.25% |
| N | 200.000 | 1200 | 68.08% | 4517.356 | 50.755 | 5.75% |
| N | 500.000 | 1200 | 15.42% | 1850.199 | 82.042 | 78.67% |
| N | 1000.000 | 1200 | 0.67% | 28.010 | 114.293 | 99.33% |
| calendar | 0.000 | 1200 | 77.33% | 3929.029 | 20.088 | 0.00% |
| calendar | 0.500 | 1200 | 73.50% | 2433.772 | 30.845 | 0.75% |
| calendar | 0.800 | 1200 | 68.67% | 576.449 | 15.093 | 0.00% |
| distance | 2000.000 | 720 | 71.39% | 584.074 | 14.002 | 0.00% |
| distance | 3500.000 | 720 | 73.06% | 1610.122 | 24.674 | 0.28% |
| distance | 5000.000 | 720 | 76.25% | 2567.393 | 32.668 | 0.14% |
| hotspot | 0.000 | 1200 | 73.50% | 2439.858 | 31.558 | 0.50% |
| hotspot | 0.500 | 1200 | 73.25% | 2371.055 | 32.682 | 0.92% |
| hotspot | 0.800 | 1200 | 73.67% | 2389.412 | 30.431 | 0.25% |
| rate | 50.000 | 1200 | 73.42% | 2030.688 | 29.986 | 0.92% |
| rate | 100.000 | 1200 | 73.00% | 2557.776 | 33.036 | 0.83% |
| rate | 200.000 | 1200 | 72.92% | 2697.469 | 33.110 | 0.83% |
| span | 120.000 | 1200 | 73.92% | 1372.889 | 23.491 | 0.25% |
| span | 300.000 | 1200 | 73.17% | 2386.497 | 31.180 | 0.67% |
| span | 600.000 | 1200 | 73.42% | 2872.179 | 34.677 | 0.50% |

本次最明显的承载边界来自候选任务规模：联合规则在N=200时超时5.75%，N=500时成功率15.42%/超时78.67%，N=1000时成功率0.67%/超时99.33%。高负载下50ms完整响应目标没有达到；不能只以默认N100结果外推大规模可用性。背景日历p=.8下成功率下降而p95变短，说明失败更快或可编辑机会变少，不能只据时延更低宣称更好。热点与基础速率曲线在此分布下差异很小，不构成严格等效或物理链路不重要的证明。

## 6. 操作比较与机制比较

**历史操作表**复用P4预定专项100基实例的原八方法主调用，非P5新增样本。各法共享物理、冻结、完整50ms及Bmax5，但搜索域不同，不能用于孤立机制归因。来源文件哈希和ID见historical_operational_provenance.json。P4历史操作与P5新机制在不同运行时段测量，不能用跨表时延或成功率变化证明实现优化；P5消融300和专项100也不是同一分层权重或同一计时批次。

| method | applicable | online_success | U_exec_mean | p95_ms | timeout_rate |
|---|---|---|---|---|---|
| ALNS-ISL | 1200 | 56.70% | 1773.255 | 52.516 | 25.90% |
| CP-SAT-50ms | 1200 | 17.33% | 363.010 | 83.291 | 42.08% |
| Fixed-PALR | 1200 | 72.42% | 2379.848 | 24.094 | 2.83% |
| Frozen-Greedy | 1200 | 70.33% | 2239.421 | 49.261 | 4.83% |
| Minimal-Repair | 1200 | 72.00% | 2387.464 | 17.103 | 2.42% |
| PUCT-ISL | 1200 | 49.43% | 1531.397 | 53.105 | 33.33% |
| Rule-PALR | 1200 | 71.75% | 2374.702 | 23.383 | 3.00% |
| Validation-Best-Fixed | 1200 | 72.58% | 2402.499 | 21.000 | 2.00% |

**P5同域机制表**固定E与B2，局部PALR、局部CP、局部PUCT/ALNS比较如下。CP构模计入总预算，UNKNOWN/未返回可行解保留，不等同物理不可行。随机法五种子先在事件内平均。

| label | applicable | success_equivalent | online_success | U_exec_mean | p95_ms | timeout_rate |
|---|---|---|---|---|---|---|
| ALNS-local | 1200 | 549.000 | 45.75% | 1334.525 | 51.931 | 42.18% |
| CP-local | 1200 | 777.000 | 64.75% | 1616.138 | 61.133 | 15.75% |
| PALR-local | 1200 | 881.000 | 73.42% | 2444.407 | 37.752 | 0.42% |
| PUCT-local | 1200 | 854.400 | 71.20% | 2374.324 | 47.795 | 3.07% |

PUCT40/100/400模拟请求仍共享50ms，实际完成模拟数及上限终止见simulation_actual_work.csv，实际最大深度与展开节点见simulation_depth_summary.csv及保留种子行的simulation_depth_per_call.csv.gz。未完成请求预算的搜索不能被解释为充分搜索下的算法质量比较。

离线审计还检查了PALR在验证基准计划后、建立E元数据前合作式早停的路径：空元数据不作为放宽承诺的依据，须独立证实无编辑且原幸存计划完整保留，并逐项检查真实E外保持项。调查经过、首次预检失败与修订依据见[验收调查记录](https://github.com/Liu-Jiye/Online-Resilience-Reconstruction-of-Satellite-Information-Distribution-Task-Schemes/blob/27fa69fa54fff94d31ec8b946fac8a41797f59d0/experiment_runs/reports/p5/P5-20261118/ACCEPTANCE_REVIEW_NOTES.md)，实际记录见local_domain_early_returns.json。原始输出未改写。

## 7. 冻结异常与共享预算升级

| label | variant | cases | frozen_conflict | online_success | timeout |
|---|---|---|---|---|---|
| Fixed-PALR | frozen_cancel | 25 | 25 | 0 | 0 |
| Fixed-PALR | frozen_window | 25 | 25 | 0 | 0 |
| Fixed-PALR | paired_normal_control | 50 | 0 | 49 | 1 |
| Minimal-Repair | frozen_cancel | 25 | 25 | 0 | 0 |
| Minimal-Repair | frozen_window | 25 | 25 | 0 | 0 |
| Minimal-Repair | paired_normal_control | 50 | 0 | 50 | 0 |
| Rule-PALR | frozen_cancel | 25 | 25 | 0 | 0 |
| Rule-PALR | frozen_window | 25 | 25 | 0 | 0 |
| Rule-PALR | paired_normal_control | 50 | 0 | 50 | 0 |
| Validation-Best-Fixed | frozen_cancel | 25 | 25 | 0 | 0 |
| Validation-Best-Fixed | frozen_window | 25 | 25 | 0 | 0 |
| Validation-Best-Fixed | paired_normal_control | 50 | 0 | 50 | 0 |

25冻结取消、25冻结窗口失效与50正常对照均在事前固定列表。按预定列表前50个取样，分层实际为40个D1、10个Starlink，未覆盖OneWeb；因此该异常识别结论不外推OneWeb。正确输出为frozen_conflict而非违反物理约束的“可行修复”；正常对照的frozen_conflict为误报。

四种方法各自均识别全部50个异常，50个正常对照均无frozen_conflict误报。固定PALR的正常对照有1次超时（49/50在线成功）；异常识别正确与正常调用按时完成分开评价。

升级冻结阈值为 **0.95**，验证触发比例 **37.22%**（720个验证条件），按预定“离0.2最近、同距取较小阈值”选择，未读取测试或精确答案触发。验证恢复比仅作触发，未用于夸大零基线效用增益。

| label | applicable | success_equivalent | online_success | U_exec_mean | conditional_M_all | p95_ms | p99_ms | timeout_rate |
|---|---|---|---|---|---|---|---|---|
| ALNS-only | 1200 | 694.600 | 57.88% | 1797.646 | 1.372 | 51.168 | 52.943 | 24.67% |
| PALR-only | 1200 | 876.000 | 73.00% | 2439.960 | 2.039 | 37.686 | 48.338 | 0.58% |
| PUCT-only | 1200 | 674.800 | 56.23% | 1798.599 | 1.359 | 51.223 | 53.757 | 23.55% |
| Upgrade-ALNS | 1200 | 750.600 | 62.55% | 1435.308 | 0.003 | 56.673 | 63.630 | 36.53% |
| Upgrade-PUCT | 1200 | 754.400 | 62.87% | 1605.267 | 0.000 | 56.682 | 64.978 | 30.05% |

| label | applicable | trigger_rate | first_phase_over10_equivalent | extra_success_equivalent | lost_success_equivalent | net_success_equivalent | execution_utility_difference |
|---|---|---|---|---|---|---|---|
| ALNS-only | 1200 | 0.00% | 0.000 | 9.400 | 190.800 | -181.400 | -642.314 |
| PALR-only | 1200 | 0.00% | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 |
| PUCT-only | 1200 | 0.00% | 0.000 | 5.200 | 206.400 | -201.200 | -641.362 |
| Upgrade-ALNS | 1200 | 37.52% | 267.000 | 5.200 | 130.600 | -125.400 | -1004.652 |
| Upgrade-PUCT | 1200 | 37.83% | 262.200 | 5.600 | 127.200 | -121.600 | -834.693 |

额外/丢失成功数是五种子在事件内平均后的等价事件数。对PALR-only与search-only的配对区间分开保存。PALR10ms为Python合作式子预算，超过10ms次数如实报告，全部实际成本扣入共享50ms；未给第二阶段额外50ms。最终总调用超时即失败，晚到可行计划只作审计证据。

| left | right | paired_events | online_success_difference | online_success_ci95_low | online_success_ci95_high | U_exec_difference |
|---|---|---|---|---|---|---|
| Upgrade-PUCT | PALR-only | 1200 | -10.13% | -11.43% | -8.83% | -834.693 |
| Upgrade-PUCT | PUCT-only | 1200 | 6.63% | 5.28% | 8.00% | -193.332 |
| Upgrade-ALNS | PALR-only | 1200 | -10.45% | -11.83% | -9.10% | -1004.652 |
| Upgrade-ALNS | ALNS-only | 1200 | 4.67% | 2.83% | 6.48% | -362.338 |

Upgrade-PUCT成功率62.87%、超时率30.05%；相对PALR-only差-10.133个百分点，探索性95%区间[-11.433,-8.833]；相对PUCT-only成功率差+6.633个百分点，但平均执行效用差-193.332。 Upgrade-ALNS成功率62.55%、超时率36.53%；相对PALR-only差-10.450个百分点，探索性95%区间[-11.834,-9.100]；相对ALNS-only成功率差+4.667个百分点，但平均执行效用差-362.338。

本次两个升级版本相对PALR-only的成功率差区间均低于零，同时完整调用尾部和执行效用恶化，因此不支持将本实现作为已验证有益的升级策略。相对搜索-only的成功率增加也不能抹去执行效用下降。该结果限制的是冻结的10ms合作式首阶段、现有阈值及两搜索实现，不是更强搜索理论上无用或其他升级机制必然失败。

候选阈值的验证触发率若均偏离约20%的目标，只能报告冻结候选集内的选择，不能声称实现了20%升级率；本次不根据测试结果扩展候选或重新调参。升级收益应同时对PALR-only和对应search-only判断，不能只挑较弱对照。

## 8. CP-SAT参考、跨星座与连续补充

100个CP-SAT初始参考尝试状态：`{'OPTIMAL': 100}`。总30s包含构模，单线程、固定种子，原始效用目标、不施加B5。所有原生模型、响应及计划保留；响应解提取与独立ISL检查通过，只有OPTIMAL称原生求解器证明最优。FEASIBLE不冒充最优，UNKNOWN不以贪心参考替代。参考耗时与在线耗时分开。

| label | applicable | online_success | U_exec_mean | p95_ms | timeout_rate |
|---|---|---|---|---|---|
| Fixed-PALR | 1200 | 73.08% | 2436.798 | 33.741 | 1.17% |
| Minimal-Repair | 1200 | 73.50% | 2457.594 | 29.962 | 0.33% |
| Rule-PALR | 1200 | 73.33% | 2446.243 | 35.757 | 0.83% |
| Validation-Best-Fixed | 1200 | 72.50% | 2419.542 | 35.784 | 1.83% |

CP参考下Minimal成功882/1200，联合规则880/1200，默认固定877/1200，验证固定870/1200；没有显示联合规则稳定胜过简单修复。原生OPTIMAL仅针对本离散初始参考的原始效用目标，不是在线修复或词典序最优证明。

该敏感性比较四个轻量修复方法，共享每个CP参考与重新生成的事件。参考改变也可能改变取消/冻结成员；它是参考构造整体敏感性，不是完全相同事件的单变量算法性能因果试验。未声称在CP参考上重新完成全部八方法操作比较。

跨星座仅用Starlink验证格/规则候选选择参数，冻结后在预定OneWeb30测试实例上运行四轻量法。选择凭据transfer_selection.json明确未用OneWeb验证/测试调参；这是既有测试对象的迁移补充，不代表全新独立星座总体。本补充没有PUCT或ET，四轻量法不读取搜索密度先验；通用封存仍记录既有search_training_statistics.json哈希，但该统计未参与本迁移方法动作，不声称已另训Starlink密度先验。

| label | applicable | online_success | U_exec_mean | p95_ms | timeout_rate |
|---|---|---|---|---|---|
| Fixed-PALR | 360 | 77.22% | 2584.572 | 32.194 | 0.00% |
| Minimal-Repair | 360 | 76.94% | 2558.053 | 24.522 | 0.56% |
| Rule-PALR | 360 | 76.11% | 2564.436 | 28.435 | 0.56% |
| Validation-Best-Fixed | 360 | 75.83% | 2561.344 | 27.758 | 0.83% |

OneWeb迁移中默认固定成功278/360，Minimal277/360，规则274/360，Starlink验证择优固定273/360；该固定30基实例补充未显示迁移后的自适应优势，不能据此宣称跨星座泛化贡献已经成立。

连续补充为100轨迹×10事件×4方法，间隔300s，各法持有自己的参考。已开始项（包括恰好在当前时刻开始）全部冻结，未来项再保护60%；完成任务效用一次累计，完成/过期任务不复活，取消和奖励持续。无效或超时调用执行既有可行承诺回退，回退不计在线成功。独立复算状态推进、每次完成集合和累计效用；统计单位为轨迹。

连续轨迹交付效用、累计干扰、失败恢复、过期未服务和窗口错失见continuous_trajectories.csv与continuous_summary.csv。原始轨迹日志将N/A也计入“未在线成功”计数；发布表独立重算适用事件分母、失败与恢复，另保留原始计数，N/A不当作算法失败。窗口错失定义为：至5400未执行且未取消、首次出现时至少存在足够长的几何/任务窗口；同时单列从未具备单任务窗口的未服务任务，不把二者混同为拥塞或修复失败。

| method | delivered_utility_mean | completed_tasks_mean | applicable_events_sum | failures_sum | failure_to_success_recoveries_sum | cumulative_movement_mean | unserved_with_individually_feasible_window_mean |
|---|---|---|---|---|---|---|---|
| Fixed-PALR | 1733.220 | 29.660 | 1000 | 247 | 247 | 2.550 | 30.490 |
| Minimal-Repair | 1703.990 | 29.320 | 1000 | 248 | 248 | 0.000 | 31.020 |
| Rule-PALR | 1735.550 | 29.680 | 1000 | 248 | 247 | 0.000 | 30.480 |
| Validation-Best-Fixed | 1732.580 | 29.650 | 1000 | 247 | 247 | 0.000 | 30.520 |

连续状态另由acceptance_details.json独立逐步重建：自己的上次可执行输出/回退到下一参考、奖励和取消持续、任务到期与完成后移出、release随时间裁剪、已开始项及额外未来承诺冻结、完成效用一次累计。上述轨迹均值只描述固定100轨迹，不以某方法自身形成的不同后续事件数宣称严格同事件因果优势。

## 9. IPC适用性审计

固定提交 `cf19edf7c53d1540ddbb396c642595e0926ee552`：2域文件、40问题文件；40/40通过S表达式结构解析，原始规范化与去标识符规范化后均40种文本。20对同编号问题的对象和目标均相同，初始事实不同，因而不能当40个独立任务分布。两个域各有5个durative-action；time域还含数值fluents。

结构解析不等于PDDL语义/类型验证。完整时序规划器、VAL等验证适配器均未接入；初始求解尝试、可求初始计划数、时序验证计划数、IPC性能事件均为**未执行**。审计未发现仓库许可证文件，未分发原始PDDL；交付固定URL、SHA256及结构元数据，原始文件保留本地缓存。

## 10. 验收、风险与下一阶段边界

验收从完整原始分片重建：每个输入哈希、源码冻结、计划/初始计划/编辑轨迹、B预算、冻结与双端窗口约束、外层截止、原始与执行效用，以及每批预期调用数。失败、N/A、迟到和非法输出全部保留。历史字节检查的有意修改仅限experiment_runs当前导航/状态，其余旧证据不变；具体结果见final_acceptance.json与historical_integrity.json。

运行仍是合成需求与公开轨道假设派生窗口，非真实星间通信测量。Docker/WSL、宿主机调度及Python合作式检查不能保证硬实时；搜索内核计时不能替代完整外层调用。该阶段不提升“规则必然胜过验证固定”“搜索理论上较差”“真实系统已部署”的证据等级。

原始调用按gzip分片发布；tables中同时提供原始种子行、事件内均值、分层/分扰动、条件质量和必要配对区间。图均有PNG/PDF与可复现脚本。复算命令见[REPRODUCE.md](https://github.com/Liu-Jiye/Online-Resilience-Reconstruction-of-Satellite-Information-Distribution-Task-Schemes/blob/27fa69fa54fff94d31ec8b946fac8a41797f59d0/experiment_runs/reports/p5/P5-20261118/REPRODUCE.md)，总清单见acceptance_manifest.json。

**P5完成后停止。P6未开始，需用户指定后续阶段。**

本地阅读版只将相对链接改为封存提交链接；正文结果与Git报告一致。完整原始计划、逐调用和输入证据见[Git封存目录](https://github.com/Liu-Jiye/Online-Resilience-Reconstruction-of-Satellite-Information-Distribution-Task-Schemes/tree/27fa69fa54fff94d31ec8b946fac8a41797f59d0/experiment_runs/reports/p5/P5-20261118)。
